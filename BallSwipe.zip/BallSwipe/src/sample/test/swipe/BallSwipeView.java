package sample.test.swipe;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

public class BallSwipeView extends View {

    Context context;
	
	//set one of the skew, rotation, and translate to be true to see the effect
	boolean skew = true;
	boolean rotation = false;
	boolean translate = false;
	
	float originXLocation = 100;
	float originYLocation = 100;
	float horizontal = 0;
	float vertical = 0;
	float distance = 0;
	float angle = 0;
	float deltaAngle = 0;
	float radius = .3f * getWidth();
	
	MotionEvent downEvent;	//start of swipe
	MotionEvent moveEvent;	//current location of swipe
	
	public BallSwipeView(Context context) {
		super(context);
		this.context = context;
	}
	
	@Override
	protected void onDraw(Canvas canvas) {

		final int width = getWidth();
		final int height = getHeight();
		final float radius = .3f * width;

		canvas.drawColor(Color.WHITE);	//background
		
		Paint paint = new Paint();
		paint.setColor(Color.BLUE);
		paint.setStyle(Paint.Style.FILL);	//vs. STROKE
		
		if (rotation){		
			angle = angle + deltaAngle;
			canvas.rotate(-angle/50);
			canvas.skew(.5f, .2f);
		} 
		
		if (skew){
			canvas.skew(horizontal/100, vertical/100);
		} 
		
		if (translate) {
		    originXLocation = originXLocation + horizontal;
		    originYLocation = originYLocation + vertical;
		    //Toast.makeText(context, originXLocation + " x " + originYLocation, Toast.LENGTH_LONG).show();
		   
		}
	    canvas.translate(originXLocation, originYLocation);
		canvas.drawCircle(0, 0, radius, paint);
	}
	
	public void touch(MotionEvent event) {
		switch(event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			downEvent = MotionEvent.obtain(event);	//copy it
			return;
			
		case MotionEvent.ACTION_UP:
			downEvent = null;
			return;
			
		case MotionEvent.ACTION_MOVE:
			moveEvent = event;
			break;
			
		default:
			return;
		}

		horizontal = moveEvent.getX() - downEvent.getX();
		vertical = moveEvent.getY() - downEvent.getY();
		distance = (float)Math.hypot(horizontal, vertical);
		deltaAngle = (float)(Math.atan2(-vertical, horizontal) * 180 / Math.PI);
		
		invalidate(); //trigger onDraw() to be called
	}
}
