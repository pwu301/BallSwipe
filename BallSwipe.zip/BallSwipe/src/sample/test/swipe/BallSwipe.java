package sample.test.swipe;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;

public class BallSwipe extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.main);

		BallSwipeView ballSwipeView = new BallSwipeView(this);
		
		ballSwipeView.setOnTouchListener(new View.OnTouchListener() {
        	@Override
        	public boolean onTouch(View v, MotionEvent event) {
        		((BallSwipeView)v).touch(event);
        		return true;
        	}
        });
		
		setContentView(ballSwipeView);
    }
}